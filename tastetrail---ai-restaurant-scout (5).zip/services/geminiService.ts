
import { GoogleGenAI, Type, Modality, Chat, GenerateContentResponse } from "@google/genai";
import { TasteProfile, Restaurant, PalateProfile, User, GroundingSource } from "../types";

export type ScoutError = 'QUOTA_EXCEEDED' | 'NETWORK_OFFLINE' | 'LOGIC_CRASH' | 'TIMEOUT';

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

async function callWithRetry<T>(fn: () => Promise<T>, retries = 5, delay = 2000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const status = error?.status || error?.code || 0;
    const msg = error?.message?.toLowerCase() || "";
    const isRetryable = status === 429 || status >= 500 || msg.includes('quota') || msg.includes('exhausted');
    
    if (isRetryable && retries > 0) {
      await new Promise(r => setTimeout(r, delay));
      return callWithRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

function safeJsonParse(text: string): any {
  let cleaned = text.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  try {
    return JSON.parse(cleaned);
  } catch (e) {
    return [];
  }
}

export function extractGroundingSources(response: GenerateContentResponse): GroundingSource[] {
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sources: GroundingSource[] = [];
  
  chunks.forEach((chunk: any) => {
    if (chunk.web?.uri) {
      sources.push({ title: chunk.web.title, uri: chunk.web.uri });
    } else if (chunk.maps?.uri) {
      sources.push({ title: chunk.maps.title, uri: chunk.maps.uri });
    }
  });
  
  return sources;
}

export const getCityName = async (lat: number, lng: number): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response: GenerateContentResponse = await callWithRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `City for lat: ${lat}, lng: ${lng}. Return ONLY the city name.`,
    }));
    return response.text?.trim() || "Local Area";
  } catch (e) {
    return "Local Area";
  }
};

export const createHealthChat = (): Chat => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are TasteTrail's Wellness Oracle. Use Google Search to find real nutritional data and local restaurant menus. Prioritize high-protein, low-carb, or specific dietary results. Always provide direct ordering URLs (Swiggy, Zomato, Uber Eats, etc.) and highlight active promo codes or deals found in your search.",
      tools: [{ googleSearch: {} }]
    },
  });
};

export const analyzeTastePersonality = async (likes: string[], dislikes: string[]): Promise<PalateProfile> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response: GenerateContentResponse = await callWithRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Likes: ${likes.join(", ")}. Dislikes: ${dislikes.join(", ")}. Create a profile.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            archetype: { type: Type.STRING },
            description: { type: Type.STRING },
            traitTags: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["archetype", "description", "traitTags"]
        }
      }
    }));
    return safeJsonParse(response.text || "{}");
  } catch (error) {
    return { archetype: "The Adventurer", description: "Exploring new flavor nodes.", traitTags: ["Global", "Bold"] };
  }
};

export const generateRestaurantAIVision = async (profile: TasteProfile, restaurant: Restaurant): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const prompt = `Photorealistic 8k food photography of a signature dish from "${restaurant.name}" (${restaurant.cuisine}). Style: ${profile.atmosphere}. Vibrant, appetizing, professional lighting.`;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: { imageConfig: { aspectRatio: "16:9" } },
    });
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
    return null;
  } catch (error) {
    return null;
  }
};

export const findRestaurants = async (
  profile: TasteProfile,
  palate: PalateProfile | null,
  location: { lat: number; lng: number } | null,
  imageContent?: string,
  user?: User,
  voiceQuery?: string
): Promise<{ restaurants: Restaurant[], rawResponse: string, sources: GroundingSource[], errorCode?: ScoutError }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const flavorString = profile.favoriteFlavors
    .map(f => `${f.name} (Intensity: ${f.level}/5)`)
    .join(", ");

  const searchPrompt = `
    Find 8 REAL-WORLD restaurants matching these requirements:
    - User Craving/Mood: ${profile.customNotes || voiceQuery || 'Any popular local spots'}
    - Sensory DNA Profile: ${flavorString || 'Balanced'}
    - Cuisines: ${profile.preferredCuisines.join(", ")}
    - Atmosphere: ${profile.atmosphere}
    - Location: ${profile.maxDistance} from lat: ${location?.lat}, lng: ${location?.lng}
    - Features: ${profile.features.join(", ")}
    
    CRITICAL MANDATE: For each restaurant, find and provide REAL DEEP LINKS for:
    1. Zomato (Dine-in/Delivery Priority)
    2. Swiggy (Delivery Priority)
    3. Magicpin (Vouchers/Cashback Priority)
    4. Uber Eats / Deliveroo (If international)
    
    If specific ordering URLs aren't found, search and provide the main restaurant ordering page URL.
    Include matchScore based on how well the restaurant matches the sensory DNA (${flavorString}).
    Include healthScore (1-100) and nutritional highlights.
    Check for active promo codes (e.g., ZOMATO50, SWIGGYIT).
  `;

  try {
    const searchResponse: GenerateContentResponse = await callWithRetry(() => ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [{ text: searchPrompt }],
      config: { tools: [{ googleSearch: {} }] },
    }));

    const rawText = searchResponse.text || "";
    const sources = extractGroundingSources(searchResponse);

    const extractionResponse: GenerateContentResponse = await callWithRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Extract restaurant data from this report into a valid JSON array: ${rawText}. 
      REQUIRED FIELDS: name, cuisine, rating, priceRange, description, address, matchScore, whyMatch, healthScore, nutritionalHighlights, allergenAlerts, swiggyUrl, zomatoUrl, uberEatsUrl, magicpinUrl, orderUrl, mapsUrl, bestPlatform, activeDeal, popularDishes(name, price, description, isVerified, orderUrl, nutritionalInfo(calories, protein, carbs, fat)), location(lat, lng).`,
      config: { responseMimeType: "application/json" },
    }));

    const extracted = safeJsonParse(extractionResponse.text || "[]");
    return { restaurants: Array.isArray(extracted) ? extracted : [], rawResponse: rawText, sources };
  } catch (e: any) {
    return { restaurants: [], rawResponse: "", sources: [], errorCode: 'LOGIC_CRASH' };
  }
};

export const generateSpeech = async (text: string): Promise<void> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const buffer = await decodeAudioData(decode(base64Audio), audioCtx, 24000, 1);
      const source = audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(audioCtx.destination);
      source.start();
    }
  } catch (e) {
    console.error("Speech synthesis failed", e);
  }
};
