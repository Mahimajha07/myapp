
import { GoogleGenAI, LiveServerMessage, Modality, Type, Blob, FunctionDeclaration } from '@google/genai';

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

export interface LiveSessionConfig {
  onTranscriptUpdate: (text: string, isUser: boolean) => void;
  onSearchTriggered: (query: string) => void;
  onStatusChange: (status: 'connecting' | 'active' | 'inactive') => void;
  onTurnComplete?: () => void;
  onNetworkError?: (error: string) => void;
}

export class ChefGullyLiveSession {
  private ai: any;
  private nextStartTime = 0;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private sources = new Set<AudioBufferSourceNode>();
  private session: any = null;
  private mediaStream: MediaStream | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private isStopping = false;

  constructor(private config: LiveSessionConfig) {}

  async start() {
    this.isStopping = false;
    this.config.onStatusChange('connecting');

    // Guideline: MUST NOT await openSelectKey. Trigger and assume success.
    if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
      window.aistudio.openSelectKey();
    }

    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      this.config.onStatusChange('inactive');
      const err = "API Key node missing. Sync required.";
      if (this.config.onNetworkError) this.config.onNetworkError(err);
      throw new Error(err);
    }
    
    // Always use new instance right before connection
    this.ai = new GoogleGenAI({ apiKey });
    
    try {
      this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      if (this.inputAudioContext.state === 'suspended') await this.inputAudioContext.resume();
      if (this.outputAudioContext.state === 'suspended') await this.outputAudioContext.resume();

      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      this.config.onStatusChange('inactive');
      if (this.config.onNetworkError) this.config.onNetworkError("Microphone connection failed.");
      throw new Error("Hardware access denied.");
    }

    const searchTool: FunctionDeclaration = {
      name: 'triggerSearch',
      parameters: {
        type: Type.OBJECT,
        description: 'Find a restaurant based on a craving.',
        properties: {
          query: { type: Type.STRING, description: 'The flavor or dish desired.' },
        },
        required: ['query'],
      },
    };

    try {
      const sessionPromise = this.ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            if (this.isStopping || !this.inputAudioContext || !this.mediaStream) return;
            this.config.onStatusChange('active');
            
            const source = this.inputAudioContext.createMediaStreamSource(this.mediaStream);
            this.scriptProcessor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            this.scriptProcessor.onaudioprocess = (e) => {
              if (this.isStopping) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then((session: any) => {
                if (session && !this.isStopping) {
                  session.sendRealtimeInput({ media: pcmBlob });
                }
              }).catch(() => {});
            };

            source.connect(this.scriptProcessor);
            this.scriptProcessor.connect(this.inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (this.isStopping) return;
            
            const audioBase64 = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioBase64 && this.outputAudioContext && (this.outputAudioContext.state as string) !== 'closed') {
              try {
                if (this.outputAudioContext.state === 'suspended') await this.outputAudioContext.resume();
                const buffer = await decodeAudioData(decode(audioBase64), this.outputAudioContext, 24000, 1);
                
                this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
                const source = this.outputAudioContext.createBufferSource();
                source.buffer = buffer;
                source.connect(this.outputAudioContext.destination);
                source.start(this.nextStartTime);
                this.nextStartTime += buffer.duration;
                this.sources.add(source);
                source.onended = () => this.sources.delete(source);
              } catch (e) {}
            }

            if (message.serverContent?.inputAudioTranscription) {
              this.config.onTranscriptUpdate(message.serverContent.inputAudioTranscription.text, true);
            }
            if (message.serverContent?.outputTranscription) {
              this.config.onTranscriptUpdate(message.serverContent.outputTranscription.text, false);
            }

            if (message.serverContent?.turnComplete) {
              if (this.config.onTurnComplete) this.config.onTurnComplete();
            }

            if (message.toolCall) {
              for (const fc of (message.toolCall.functionCalls || [])) {
                if (fc.name === 'triggerSearch') {
                  this.config.onSearchTriggered(fc.args.query as string);
                  sessionPromise.then((s: any) => {
                    if (s) s.sendToolResponse({
                      // SDK expects single object for functionResponses in tool response payload
                      functionResponses: { 
                        id: fc.id, 
                        name: fc.name, 
                        response: { result: "Search sequence initialized." } 
                      }
                    });
                  });
                }
              }
            }

            if (message.serverContent?.interrupted) {
              this.sources.forEach(s => { try { s.stop(); } catch(e) {} });
              this.sources.clear();
              this.nextStartTime = 0;
            }
          },
          onclose: (e: CloseEvent) => {
            this.stop();
          },
          onerror: (e: any) => {
            const errMsg = e?.message || "Node handshake failure.";
            if (this.config.onNetworkError) this.config.onNetworkError(`Live Node: ${errMsg}`);
            this.stop();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: "You are Chef Gully. Be quick and helpful. Use triggerSearch for all food requests.",
          tools: [{ functionDeclarations: [searchTool] }],
        },
      });

      this.session = await sessionPromise;
    } catch (err: any) {
      this.config.onStatusChange('inactive');
      if (err?.message?.includes("entity was not found") && window.aistudio) {
        window.aistudio.openSelectKey();
      }
      if (this.config.onNetworkError) this.config.onNetworkError("Live Node Sync Failure.");
      throw err;
    }
  }

  stop() {
    if (this.isStopping) return;
    this.isStopping = true;

    this.sources.forEach(s => { try { s.stop(); } catch(e) {} });
    this.sources.clear();
    
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(t => t.stop());
      this.mediaStream = null;
    }

    if (this.scriptProcessor) {
      this.scriptProcessor.disconnect();
      this.scriptProcessor = null;
    }

    const safeCloseContext = (ctx: AudioContext | null) => {
      if (ctx && (ctx.state as string) !== 'closed') {
        try { ctx.close().catch(() => {}); } catch (e) {}
      }
      return null;
    };

    this.inputAudioContext = safeCloseContext(this.inputAudioContext);
    this.outputAudioContext = safeCloseContext(this.outputAudioContext);

    if (this.session) {
      try { this.session.close(); } catch (e) {}
      this.session = null;
    }

    this.config.onStatusChange('inactive');
  }
}
