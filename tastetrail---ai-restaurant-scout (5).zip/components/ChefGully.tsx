
import React, { useState, useEffect, useRef } from 'react';
import { ChefGullyLiveSession } from '../services/geminiLiveService';

interface ChefGullyProps {
  context: string;
  userName?: string;
  onVoiceSearch?: (query: string) => void;
}

const MESSAGES = {
  form: ["Ready to swing through some flavors?", "Tell me what you're craving, or just tap my mic!"],
  results: ["Look at these 90%+ matches! Banana-standard!", "Tap a spot to see the deep details and order links."],
  failed: ["Ouch! The scouting grid hit a thick vine. Let's recalibrate!"],
  default: ["Ooh ooh! Ready for your next gourmet node?"]
};

export const ChefGully: React.FC<ChefGullyProps> = ({ context, userName, onVoiceSearch }) => {
  const [message, setMessage] = useState("");
  const [isBubbleOpen, setIsBubbleOpen] = useState(true);
  const [liveStatus, setLiveStatus] = useState<'inactive' | 'connecting' | 'active'>('inactive');
  const [liveTranscript, setLiveTranscript] = useState('');
  const sessionRef = useRef<ChefGullyLiveSession | null>(null);

  useEffect(() => {
    const currentMessages = MESSAGES[context as keyof typeof MESSAGES] || MESSAGES.default;
    setMessage(currentMessages[Math.floor(Math.random() * currentMessages.length)]);
  }, [context]);

  const toggleLiveChat = async () => {
    if (liveStatus !== 'inactive') {
      sessionRef.current?.stop();
      return;
    }

    setLiveTranscript('');
    const session = new ChefGullyLiveSession({
      onStatusChange: (status) => setLiveStatus(status),
      onTranscriptUpdate: (text, isUser) => {
        setLiveTranscript(prev => `${isUser ? 'You' : 'Chef'}: ${text}`);
        setIsBubbleOpen(true);
      },
      onSearchTriggered: (query) => onVoiceSearch?.(query),
    });

    sessionRef.current = session;
    try { await session.start(); } catch (err) { setLiveStatus('inactive'); }
  };

  return (
    <div className="fixed bottom-28 right-6 z-[1200] flex flex-col items-end pointer-events-none">
      {isBubbleOpen && (
        <div className="mb-4 mr-2 max-w-[200px] animate-in slide-in-from-bottom-4 pointer-events-auto">
          <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl p-4 rounded-3xl rounded-br-none shadow-2xl border-2 border-sunset relative">
            <button onClick={() => setIsBubbleOpen(false)} className="absolute -top-2 -right-2 w-6 h-6 bg-sunset text-white rounded-full flex items-center justify-center text-[10px] shadow-lg">
              <span className="google-symbols">close</span>
            </button>
            <p className="text-[11px] font-black leading-tight text-slate-800 dark:text-slate-100 italic">
              {liveStatus === 'active' ? (liveTranscript || "Listening...") : message}
            </p>
            <div className="absolute -bottom-2 right-0 w-3 h-3 bg-white dark:bg-slate-900 border-r-2 border-b-2 border-sunset rotate-45"></div>
          </div>
        </div>
      )}

      <div className="pointer-events-auto group relative">
        {(liveStatus === 'active' || liveStatus === 'connecting') && (
          <div className="absolute inset-0 scale-[2.5] rounded-full animate-ping bg-sunset/20"></div>
        )}
        <button 
          onClick={toggleLiveChat}
          className={`w-20 h-20 rounded-[2.5rem] relative transition-all duration-500 hover:scale-110 active:scale-90 shadow-2xl flex items-center justify-center border-4 border-white dark:border-slate-800 overflow-hidden ${
            liveStatus === 'active' ? 'bg-mint' : 'bg-sunset'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-50"></div>
          <span className="text-4xl drop-shadow-lg relative z-10">{liveStatus === 'active' ? '🎙️' : '🐒'}</span>
          <div className={`absolute bottom-1 right-1 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center text-[8px] font-black text-white ${liveStatus === 'active' ? 'bg-rose-500 animate-pulse' : 'bg-midnight'}`}>
            <span className="google-symbols text-[12px]">{liveStatus === 'active' ? 'mic' : 'bolt'}</span>
          </div>
        </button>
      </div>
    </div>
  );
};
