
import React, { useState } from 'react';

interface FoodieRulesProps {
  onAccept: () => void;
  userName: string;
}

const RULES = [
  {
    title: "Rule #1: Chat, Don't Tap",
    desc: "Tap Chef Gully to talk! Tell him you want 'spicy street food' or 'romantic rooftop vibes'. He's all ears!",
    icon: "🎙️",
    color: "bg-rose-500"
  },
  {
    title: "Rule #2: Feed the Vision",
    desc: "Found a dish on Instagram? Upload a photo! The Scout identifies the cuisine and finds local matches instantly.",
    icon: "📸",
    color: "bg-amber-500"
  },
  {
    title: "Rule #3: The 90% Match",
    desc: "Any spot with a 90%+ match score is your 'Soul Food'. Don't ignore it—it's calculated specifically for your palate!",
    icon: "🔥",
    color: "bg-emerald-500"
  },
  {
    title: "Rule #4: No FOMO",
    desc: "We check Swiggy vs Zomato prices in real-time. If there's a better deal, Chef Gully will find it first.",
    icon: "🍌",
    color: "bg-orange-500"
  }
];

export const FoodieRules: React.FC<FoodieRulesProps> = ({ onAccept, userName }) => {
  const [activeStep, setActiveStep] = useState(0);

  const next = () => {
    if (activeStep < RULES.length - 1) {
      setActiveStep(activeStep + 1);
      if ('vibrate' in navigator) navigator.vibrate(10);
    } else {
      onAccept();
    }
  };

  return (
    <div className="flex flex-col items-center justify-center py-6 text-center animate-in fade-in zoom-in duration-500">
      <div className="max-w-md w-full space-y-8">
        <div className="space-y-2">
          <div className="text-5xl mb-4">📜</div>
          <h2 className="text-4xl font-serif font-black text-gray-900 dark:text-white leading-tight">
            The Golden Rules
          </h2>
          <p className="text-[10px] font-black text-rose-600 dark:text-red-400 uppercase tracking-[0.3em]">
            Listen up, {userName.split(' ')[0]}!
          </p>
        </div>

        <div className="relative h-64 flex items-center justify-center">
          {RULES.map((rule, i) => (
            <div 
              key={i}
              className={`absolute inset-0 flex flex-col items-center justify-center transition-all duration-500 ${
                i === activeStep ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-10 scale-95 pointer-events-none'
              }`}
            >
              <div className={`w-20 h-20 ${rule.color} text-white rounded-[2rem] flex items-center justify-center text-4xl shadow-2xl mb-6 transform rotate-6`}>
                {rule.icon}
              </div>
              <h3 className="text-xl font-black text-gray-800 dark:text-white mb-3">{rule.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium leading-relaxed px-4">
                {rule.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="pt-8 space-y-6">
          <div className="flex justify-center gap-2">
            {RULES.map((_, i) => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === activeStep ? 'w-8 bg-rose-600' : 'w-2 bg-gray-200 dark:bg-gray-800'
                }`}
              />
            ))}
          </div>

          <button 
            onClick={next}
            className="w-full bg-rose-600 text-white py-5 rounded-[2rem] font-black text-xl shadow-2xl shadow-rose-200 dark:shadow-rose-900/20 active:scale-95 transition-all flex items-center justify-center gap-3"
          >
            {activeStep === RULES.length - 1 ? "Let's Eat! 🍽️" : "Got it! Next Rule"}
          </button>
        </div>
      </div>
    </div>
  );
};
