
import React from 'react';
import { GastroStory } from '../types';

const MOCK_STORIES: GastroStory[] = [
  { id: '1', restaurantName: 'Pasta Heaven', dishName: 'Truffle Tagliatelle', image: 'https://images.unsplash.com/photo-1473093226795-af9932fe5856?auto=format&fit=crop&w=400&q=80', avatar: '🍝', isLive: true },
  { id: '2', restaurantName: 'Sushi Zen', dishName: 'Dragon Roll', image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=400&q=80', avatar: '🍣', isLive: true },
  { id: '3', restaurantName: 'Burger Lab', dishName: 'Monster Melt', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=400&q=80', avatar: '🍔' },
  { id: '4', restaurantName: 'Green Bowl', dishName: 'Quinoa Power', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=400&q=80', avatar: '🥗' },
  { id: '5', restaurantName: 'Spice Route', dishName: 'Biryani Feast', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80', avatar: '🍛', isLive: true },
];

export const GastroStories: React.FC = () => {
  return (
    <div className="w-full overflow-x-auto no-scrollbar py-4 px-6 mb-8 flex gap-5">
      {MOCK_STORIES.map((story) => (
        <button 
          key={story.id} 
          className="flex-shrink-0 flex flex-col items-center gap-2 group relative"
        >
          <div className={`relative w-20 h-20 rounded-[2rem] p-1 transition-all group-hover:scale-105 active:scale-95 ${story.isLive ? 'bg-gradient-to-tr from-rose-500 via-amber-500 to-rose-500 animate-pulse' : 'bg-slate-200 dark:bg-slate-800'}`}>
            <div className="w-full h-full rounded-[1.8rem] bg-white dark:bg-slate-900 p-0.5 overflow-hidden">
               <img src={story.image} className="w-full h-full object-cover rounded-[1.7rem]" alt={story.dishName} />
            </div>
            <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg border-2 border-slate-50 dark:border-slate-800 flex items-center justify-center text-lg">
              {story.avatar}
            </div>
            {story.isLive && (
              <div className="absolute -top-1 -left-1 bg-rose-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded-full border border-white dark:border-slate-900 animate-bounce">
                LIVE
              </div>
            )}
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 group-hover:text-rose-600 transition-colors truncate max-w-[80px]">
            {story.restaurantName}
          </span>
        </button>
      ))}
    </div>
  );
};
