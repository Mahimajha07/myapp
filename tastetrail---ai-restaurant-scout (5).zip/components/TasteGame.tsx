
import React, { useState, useRef, TouchEvent, useEffect } from 'react';

interface TasteGameProps {
  onComplete: (selections: { likes: string[], dislikes: string[] }) => void;
}

const CARDS = [
  { 
    id: 'malabar', 
    label: 'Malabar Parotta', 
    img: 'https://images.unsplash.com/photo-1630409351241-e90e7f5e434d?auto=format&fit=crop&w=800&q=80', 
    emoji: '🫓',
    desc: 'Flaky, buttery layers of heaven'
  },
  { 
    id: 'chettinad', 
    label: 'Chettinad Curry', 
    img: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=800&q=80', 
    emoji: '🌶️',
    desc: 'Bold, peppery regional spices'
  },
  { 
    id: 'hyderabadi', 
    label: 'Spiced Biryani', 
    img: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80', 
    emoji: '🍛',
    desc: 'Aromatic basmati & slow-cooked meat'
  },
  { 
    id: 'bengali', 
    label: 'Mustard Fish', 
    img: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&w=800&q=80', 
    emoji: '🐟',
    desc: 'Pungent mustard & river fish'
  },
  { 
    id: 'paneer', 
    label: 'Tandoori Tikka', 
    img: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=800&q=80', 
    emoji: '🍢',
    desc: 'Smoky, charred, and tender'
  },
  { 
    id: 'dosa', 
    label: 'Ghee Podi Dosa', 
    img: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80', 
    emoji: '🫓',
    desc: 'Crispy edges & spicy gunpowder'
  },
  { 
    id: 'healthy', 
    label: 'Superfood Salad', 
    img: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80', 
    emoji: '🥗',
    desc: 'Crunchy greens & high protein'
  },
  { 
    id: 'global', 
    label: 'Truffle Pasta', 
    img: 'https://images.unsplash.com/photo-1473093226795-af9932fe5856?auto=format&fit=crop&w=800&q=80', 
    emoji: '🍝',
    desc: 'Earthily rich & velvety'
  }
];

export const TasteGame: React.FC<TasteGameProps> = ({ onComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selections, setSelections] = useState<{ likes: string[], dislikes: string[] }>({ likes: [], dislikes: [] });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [showSwipeHint, setShowSwipeHint] = useState(true);
  
  const touchStartPos = useRef({ x: 0, y: 0 });

  const handleDecision = (like: boolean) => {
    const item = CARDS[currentIndex];
    const newSelections = {
      likes: like ? [...selections.likes, item.label] : selections.likes,
      dislikes: !like ? [...selections.dislikes, item.label] : selections.dislikes
    };

    setDragOffset({ x: 0, y: 0 });
    setShowSwipeHint(false);

    if (currentIndex < CARDS.length - 1) {
      setSelections(newSelections);
      setCurrentIndex(currentIndex + 1);
    } else {
      onComplete(newSelections);
    }
  };

  const onTouchStart = (e: TouchEvent) => {
    touchStartPos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    setIsDragging(true);
    setShowSwipeHint(false);
  };

  const onTouchMove = (e: TouchEvent) => {
    if (!isDragging) return;
    const x = e.touches[0].clientX - touchStartPos.current.x;
    setDragOffset({ x, y: 0 });
  };

  const onTouchEnd = () => {
    setIsDragging(false);
    if (Math.abs(dragOffset.x) > 100) handleDecision(dragOffset.x > 0);
    else setDragOffset({ x: 0, y: 0 });
  };

  const card = CARDS[currentIndex];
  const opacity = Math.min(Math.abs(dragOffset.x) / 100, 1);

  return (
    <div className="flex flex-col items-center justify-center py-6 select-none touch-none relative min-h-[80vh]">
      <div className="mb-10 text-center space-y-2">
        <h3 className="text-3xl font-serif font-black text-gray-900 dark:text-white">Taste Discovery</h3>
        <p className="text-[10px] text-rose-600 font-black uppercase tracking-[0.3em] animate-pulse">Swipe your soul-food</p>
      </div>

      <div 
        className="relative w-80 h-[32rem] perspective-1000"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {/* Swipe Hint Overlay (Air Hand) */}
        {showSwipeHint && (
          <div className="absolute inset-0 z-[60] flex flex-col items-center justify-center pointer-events-none">
            <div className="relative animate-swipe-hint">
               <span className="google-symbols text-8xl text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.8)]">pan_tool_alt</span>
               <div className="absolute -top-12 left-1/2 -translate-x-1/2 flex gap-12 w-48 justify-between px-4">
                  <div className="flex flex-col items-center">
                    <span className="bg-rose-500 text-white p-2 rounded-full text-[10px] font-black uppercase">Nah</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="bg-emerald-500 text-white p-2 rounded-full text-[10px] font-black uppercase">Yum</span>
                  </div>
               </div>
            </div>
            <p className="mt-8 text-white font-black text-[12px] uppercase tracking-[0.3em] drop-shadow-lg">Swipe Left or Right</p>
          </div>
        )}

        <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none transition-opacity duration-200" style={{ opacity: dragOffset.x > 50 ? opacity : 0 }}>
          <div className="bg-emerald-500 text-white px-10 py-4 rounded-full font-black text-3xl shadow-[0_0_50px_rgba(16,185,129,0.5)] border-4 border-white transform -rotate-12 scale-110">YUM!</div>
        </div>
        <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none transition-opacity duration-200" style={{ opacity: dragOffset.x < -50 ? opacity : 0 }}>
          <div className="bg-rose-500 text-white px-10 py-4 rounded-full font-black text-3xl shadow-[0_0_50px_rgba(244,63,94,0.5)] border-4 border-white transform rotate-12 scale-110">NAH</div>
        </div>

        <div 
          className={`absolute inset-0 bg-white dark:bg-gray-800 rounded-[3.5rem] shadow-2xl overflow-hidden border-8 border-white dark:border-gray-700 transition-transform ${!isDragging ? 'duration-500' : ''}`}
          style={{ transform: `translate3d(${dragOffset.x}px, 0, 0) rotate(${dragOffset.x * 0.1}deg)` }}
        >
          <img src={card.img} alt={card.label} className="w-full h-full object-cover transition-transform duration-700 scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
          <div className="absolute bottom-10 left-8 right-8 space-y-2">
             <div className="flex items-center gap-3">
               <span className="bg-white/20 backdrop-blur-md w-14 h-14 rounded-2xl flex items-center justify-center text-3xl border border-white/20 shadow-xl">{card.emoji}</span>
               <div className="flex flex-col">
                 <span className="text-[10px] text-white/60 font-black uppercase tracking-[0.2em]">Regional Hero</span>
                 <h4 className="text-3xl font-serif font-black text-white leading-tight">{card.label}</h4>
               </div>
             </div>
             <p className="text-[11px] text-white/40 italic font-medium tracking-wide">"{card.desc}"</p>
          </div>
        </div>
      </div>

      <div className="flex gap-16 mt-12">
        <button onClick={() => handleDecision(false)} className="w-20 h-20 rounded-full bg-white dark:bg-gray-800 shadow-2xl flex items-center justify-center text-rose-500 border-4 border-rose-50 active:scale-90 transition-all group">
          <span className="google-symbols text-4xl font-black group-hover:rotate-90 transition-transform">close</span>
        </button>
        <button onClick={() => handleDecision(true)} className="w-20 h-20 rounded-full bg-white dark:bg-gray-800 shadow-2xl flex items-center justify-center text-emerald-500 border-4 border-emerald-50 active:scale-90 transition-all group">
          <span className="google-symbols text-4xl font-black group-hover:scale-125 transition-transform">favorite</span>
        </button>
      </div>

      <style>{`
        @keyframes swipe-hint {
          0% { transform: translateX(0); opacity: 0; }
          10% { opacity: 0.8; }
          30% { transform: translateX(80px); }
          50% { transform: translateX(0); }
          70% { transform: translateX(-80px); }
          90% { opacity: 0.8; }
          100% { transform: translateX(0); opacity: 0; }
        }
        .animate-swipe-hint {
          animation: swipe-hint 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};
