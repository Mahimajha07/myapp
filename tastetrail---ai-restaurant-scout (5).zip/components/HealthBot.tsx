
import React, { useState, useEffect, useRef } from 'react';
import { createHealthChat, extractGroundingSources } from '../services/geminiService';
import { Message, GroundingSource } from '../types';

const SUGGESTIONS = [
  "I'm craving high-protein street food...",
  "How many calories in a Butter Chicken?",
  "Best gluten-free spots in Bangalore?",
  "Keto-friendly breakfast in London...",
  "Find me a vegan dessert spot nearby.",
  "Which dish has the most omega-3 here?",
  "Low sodium Italian options in SF?",
  "Tell me about diabetic-friendly regional food."
];

export const ScoutSearchBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: "Gastro-Sync Online. I'm your discovery & wellness oracle. Ask me anything about flavor nodes, nutritional data, or global trending spots!", sender: 'ai', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [placeholder, setPlaceholder] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingIntervalRef = useRef<number | null>(null);

  // Placeholder Typing Effect
  useEffect(() => {
    let currentSuggestionIdx = 0;
    let currentCharIdx = 0;
    let isDeleting = false;

    const type = () => {
      const currentFullText = SUGGESTIONS[currentSuggestionIdx];
      
      if (isDeleting) {
        setPlaceholder(currentFullText.substring(0, currentCharIdx - 1));
        currentCharIdx--;
      } else {
        setPlaceholder(currentFullText.substring(0, currentCharIdx + 1));
        currentCharIdx++;
      }

      let typingSpeed = isDeleting ? 50 : 100;

      if (!isDeleting && currentCharIdx === currentFullText.length) {
        isDeleting = true;
        typingSpeed = 2000;
      } else if (isDeleting && currentCharIdx === 0) {
        isDeleting = false;
        currentSuggestionIdx = (currentSuggestionIdx + 1) % SUGGESTIONS.length;
        typingSpeed = 500;
      }

      typingIntervalRef.current = window.setTimeout(type, typingSpeed);
    };

    type();
    return () => {
      if (typingIntervalRef.current) clearTimeout(typingIntervalRef.current);
    };
  }, []);

  useEffect(() => {
    if (isOpen && !chatRef.current) {
      chatRef.current = createHealthChat();
    }
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (e?: React.FormEvent, textOverride?: string) => {
    if (e) e.preventDefault();
    const finalInput = textOverride || input;
    if (!finalInput.trim() || isTyping) return;

    if (!isOpen) setIsOpen(true);

    const userMsg: Message = { id: Date.now().toString(), text: finalInput, sender: 'user', timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      if (!chatRef.current) chatRef.current = createHealthChat();
      const response = await chatRef.current.sendMessage({ message: finalInput });
      const sources = extractGroundingSources(response);
      
      const aiMsg: Message = { 
        id: (Date.now() + 1).toString(), 
        text: response.text || "I'm recalibrating my data nodes. Try asking again!", 
        sender: 'ai', 
        timestamp: new Date(),
        sources: sources.length > 0 ? sources : undefined
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        text: "The scouting network is currently offline. Please attempt sync in a few moments.",
        sender: 'ai',
        timestamp: new Date()
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-6 mb-12">
      <div 
        onClick={() => !isOpen && setIsOpen(true)}
        className="relative group animate-in fade-in slide-in-from-top-4 duration-1000"
      >
        <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-rose-500 rounded-[2rem] blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 rounded-[2rem] p-2 flex items-center shadow-xl">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 ml-1">
            <span className="google-symbols text-2xl">health_metrics</span>
          </div>
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={placeholder || "Ask Wellness Assistant..."}
            className="flex-1 bg-transparent border-none outline-none px-4 py-3 font-bold text-sm text-slate-800 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600"
          />
          <button 
            onClick={(e) => { e.stopPropagation(); handleSend(); }}
            className="bg-emerald-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all active:scale-95 shadow-lg shadow-emerald-500/20"
          >
            Ask Wellness
          </button>
        </div>
      </div>

      {!isOpen && (
        <div className="flex gap-2 mt-4 overflow-x-auto no-scrollbar pb-2 animate-in fade-in slide-in-from-bottom-2 duration-1000 delay-300">
          {["Keto recipes?", "High protein spots?", "Allergy safe?", "Low calorie vibes?"].map((q) => (
            <button 
              key={q} 
              onClick={() => handleSend(undefined, q)}
              className="whitespace-nowrap bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest text-slate-500 hover:border-emerald-400 hover:text-emerald-600 transition-all shadow-sm"
            >
              {q}
            </button>
          ))}
        </div>
      )}

      {isOpen && (
        <div className="fixed inset-0 z-[1000] flex flex-col justify-end">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-500" onClick={() => setIsOpen(false)} />
          <div className="relative bg-white dark:bg-slate-900 w-full h-[90vh] rounded-t-[3.5rem] shadow-2xl flex flex-col border-t-8 border-emerald-600 animate-in slide-in-from-bottom-20 duration-500 overflow-hidden">
            
            <div className="px-8 py-6 border-b dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-950/20">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="absolute inset-0 bg-emerald-500 blur-lg opacity-20 animate-pulse"></div>
                  <div className="relative w-14 h-14 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center border-2 border-slate-100 dark:border-slate-700 shadow-xl">
                    <span className="google-symbols text-3xl text-emerald-600">health_metrics</span>
                  </div>
                </div>
                <div>
                  <h2 className="text-xl font-serif font-black dark:text-white">Wellness Assistant</h2>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                    <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Biological Data Online</p>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)} 
                className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-slate-500 hover:bg-rose-50 hover:text-rose-600 transition-all shadow-md active:scale-90"
              >
                <span className="google-symbols">close</span>
              </button>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 no-scrollbar scroll-smooth">
              {messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-4 duration-500`}>
                  <div className={`max-w-[85%] group ${
                    msg.sender === 'user' 
                    ? 'bg-emerald-600 text-white rounded-[2rem] rounded-tr-none shadow-xl shadow-emerald-500/10' 
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-[2.5rem] rounded-tl-none border border-slate-100 dark:border-slate-700'
                  } p-6 space-y-4`}>
                    <p className="text-sm font-medium leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                    
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="pt-4 border-t border-slate-200 dark:border-slate-700 space-y-3">
                        <div className="flex items-center gap-2">
                           <span className="google-symbols text-xs text-emerald-500 filled">verified</span>
                           <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 group-hover:text-emerald-500 transition-colors">Verified Grounding</p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {msg.sources.map((source, i) => (
                            <a 
                              key={i} 
                              href={source.uri} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="bg-white dark:bg-slate-700 px-4 py-2 rounded-xl text-[9px] font-bold text-slate-600 dark:text-slate-300 border border-slate-100 dark:border-slate-600 flex items-center gap-2 hover:border-emerald-500 hover:text-emerald-600 transition-all shadow-sm"
                            >
                              <span className="google-symbols text-[12px] text-emerald-500">link</span>
                              {source.title || "Health Node"}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-[2.5rem] rounded-tl-none animate-pulse flex gap-2 border border-slate-100 dark:border-slate-700">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-8 border-t dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 backdrop-blur-xl">
              <form onSubmit={handleSend} className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-amber-500 rounded-3xl blur opacity-20 group-focus-within:opacity-40 transition duration-500"></div>
                <div className="relative flex items-center bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-2xl border-2 border-slate-100 dark:border-slate-700">
                  <input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask Wellness Assistant..."
                    className="flex-1 bg-transparent border-none outline-none px-6 py-5 text-sm font-bold dark:text-white"
                  />
                  <button 
                    type="submit" 
                    disabled={isTyping}
                    className="mr-3 w-12 h-12 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg active:scale-90 transition-all hover:bg-emerald-700"
                  >
                    <span className="google-symbols">{isTyping ? 'sync' : 'send'}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
