
import React from 'react';

export type TabId = 'explore' | 'map' | 'orders' | 'profile';

interface BottomNavProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  onQuickScout: () => void;
}

const TABS = [
  { id: 'explore', label: 'Explore', icon: 'explore' },
  { id: 'map', label: 'Map', icon: 'map' },
  { id: 'orders', label: 'Bookings', icon: 'confirmation_number' },
  { id: 'profile', label: 'Profile', icon: 'person' },
] as const;

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange, onQuickScout }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-[1000] pb-[var(--safe-bottom)]">
      <div className="mx-6 mb-4 flex items-center justify-between bg-white/90 dark:bg-midnight/90 backdrop-blur-3xl px-4 py-3 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-white/20 dark:border-white/5">
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col items-center gap-1 px-4 py-2 transition-all duration-300 ${
                isActive ? 'text-sunset' : 'text-slate-400'
              }`}
            >
              <span className={`google-symbols text-2xl ${isActive ? 'filled' : ''}`}>
                {tab.icon}
              </span>
              <span className="text-[9px] font-black uppercase tracking-widest leading-none">
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute -bottom-1 w-1 h-1 bg-sunset rounded-full animate-in zoom-in" />
              )}
            </button>
          );
        })}
        
        {/* Floating Quick Action Button Integration */}
        <button 
          onClick={onQuickScout}
          className="absolute -top-8 left-1/2 -translate-x-1/2 w-16 h-16 bg-sunset text-white rounded-full shadow-[0_15px_30px_rgba(255,107,53,0.4)] flex items-center justify-center border-4 border-white dark:border-midnight hover:scale-110 active:scale-95 transition-all"
        >
          <span className="google-symbols text-3xl font-black">add</span>
        </button>
      </div>
    </div>
  );
};
