import React from 'react';

export const MapViewSkeleton: React.FC = () => {
  return (
    <div className="w-full h-[550px] md:h-[750px] bg-slate-100 dark:bg-slate-900 rounded-[4rem] border-[10px] border-amber-400 dark:border-slate-800 relative overflow-hidden flex items-center justify-center">
      <div className="absolute inset-0 bg-[radial-gradient(circle,rgba(225,29,72,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      <div className="relative">
        <div className="w-64 h-64 border-2 border-rose-500/20 rounded-full animate-ping"></div>
        <div className="absolute inset-0 w-64 h-64 border-4 border-rose-500/10 rounded-full animate-pulse flex items-center justify-center">
          <span className="google-symbols text-6xl text-rose-500/30">radar</span>
        </div>
      </div>
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md px-8 py-3 rounded-full border border-white/20">
        <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 animate-pulse text-center">Grounded Location Search...</p>
      </div>
    </div>
  );
};