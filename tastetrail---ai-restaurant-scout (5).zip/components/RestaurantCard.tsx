
import React, { useState, useMemo, useRef } from 'react';
import { Restaurant, Booking, Review, TasteProfile, User } from '../types';
import { generateRestaurantAIVision } from '../services/geminiService';

interface RestaurantCardProps {
  id?: string;
  restaurant: Restaurant;
  isHighlighted?: boolean;
  onBook: (booking: Booking | void) => void;
  onViewOnMap?: () => void;
  showNutritionalInfo?: boolean;
  userProfile?: TasteProfile | null;
  currentUser?: User | null;
  onAddReview?: (review: Review) => void;
}

const ReviewItem: React.FC<{ review: Review }> = ({ review }) => {
  return (
    <div className={`p-6 rounded-[2.5rem] border transition-all duration-300 hover:scale-[1.01] ${
      review.isUserGenerated ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-100 dark:border-rose-900' : 'bg-slate-50 dark:bg-slate-950/50 border-slate-100 dark:border-slate-800'
    } space-y-4 shadow-sm hover:shadow-md`}>
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-sm text-white font-black shadow-lg ${
            review.sentiment === 'positive' ? 'bg-emerald-500' : review.sentiment === 'negative' ? 'bg-rose-500' : 'bg-slate-400'
          }`}>
            {review.author?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-[12px] font-black text-slate-800 dark:text-slate-200">{review.author}</span>
              {review.isVerified && <span className="google-symbols text-blue-500 text-[14px] filled">verified</span>}
              {review.isUserGenerated && <span className="text-[8px] font-black uppercase text-rose-500 px-1.5 py-0.5 bg-rose-100 rounded">You</span>}
            </div>
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <span key={i} className={`google-symbols text-[12px] ${i < review.rating ? 'filled' : ''}`}>star</span>
              ))}
            </div>
          </div>
        </div>
      </div>
      <p className="text-[13px] leading-relaxed text-slate-700 dark:text-slate-300 font-medium italic">"{review.text}"</p>
    </div>
  );
};

export const RestaurantCard: React.FC<RestaurantCardProps> = ({ 
  id, restaurant, isHighlighted, onBook, onViewOnMap, userProfile, currentUser, onAddReview 
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'reviews' | 'wellness' | 'order'>('info');
  const [imageLoaded, setImageLoaded] = useState(false);
  const [aiVisionImage, setAiVisionImage] = useState<string | null>(null);
  const [isGeneratingVision, setIsGeneratingVision] = useState(false);

  // Review Input State
  const [showReviewInput, setShowReviewInput] = useState(false);
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);

  const heroImage = useMemo(() => {
    return `https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80&sig=${encodeURIComponent(restaurant.name || 'restaurant')}`;
  }, [restaurant]);

  const handleGenerateVision = async () => {
    if (!userProfile || isGeneratingVision) return;
    setIsGeneratingVision(true);
    const vision = await generateRestaurantAIVision(userProfile, restaurant);
    setAiVisionImage(vision);
    setIsGeneratingVision(false);
  };

  const handlePostReview = () => {
    if (!newReviewText.trim() || !currentUser) return;
    const review: Review = {
      author: currentUser.name,
      text: newReviewText,
      rating: newReviewRating,
      sentiment: newReviewRating >= 4 ? 'positive' : 'negative',
      isUserGenerated: true,
      isVerified: true
    };
    onAddReview?.(review);
    setNewReviewText('');
    setShowReviewInput(false);
    if ('vibrate' in navigator) navigator.vibrate(20);
  };

  const platforms = [
    { name: 'Zomato', url: restaurant.zomatoUrl, color: 'bg-[#E23744]', icon: 'restaurant', tagline: 'Dine-in & Order' },
    { name: 'Swiggy', url: restaurant.swiggyUrl, color: 'bg-[#FC8019]', icon: 'moped', tagline: 'Fastest Delivery' },
    { name: 'MagicPin', url: restaurant.magicpinUrl, color: 'bg-[#000000]', icon: 'local_offer', tagline: 'Best Cashback' },
    { name: 'Uber Eats', url: restaurant.uberEatsUrl, color: 'bg-[#06C167]', icon: 'delivery_dining', tagline: 'Global Partner' }
  ].filter(p => p.url);

  return (
    <article 
      id={id}
      className={`relative bg-white dark:bg-slate-900 rounded-[3.5rem] overflow-hidden scout-card-shadow border-2 transition-all duration-700 ${
        isHighlighted ? 'border-sunset scale-[1.03] ring-4 ring-sunset/20 z-10' : 'border-slate-50 dark:border-slate-800'
      }`}
    >
      <div className="relative h-80 group overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img 
          src={aiVisionImage || heroImage} 
          className={`w-full h-full object-cover transition-all duration-1000 group-hover:scale-110 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`} 
          onLoad={() => setImageLoaded(true)}
          alt={restaurant.name}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-midnight via-midnight/20 to-transparent"></div>
        
        <div className="absolute top-6 left-6 flex gap-2">
           <div className="bg-midnight/80 backdrop-blur-xl text-white px-4 py-2 rounded-2xl font-black text-sm border border-white/10 shadow-2xl">
              {restaurant.matchScore}% <span className="text-[8px] opacity-60 uppercase">Match 💖</span>
           </div>
           <div className="bg-emerald-500/80 backdrop-blur-xl text-white px-4 py-2 rounded-2xl font-black text-sm border border-white/10 shadow-2xl">
              {restaurant.healthScore || 85}% <span className="text-[8px] opacity-60 uppercase">Wellness 🥗</span>
           </div>
        </div>

        <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end">
           <div className="space-y-1">
             <p className="text-[9px] font-black uppercase tracking-[0.3em] text-sunset">{restaurant.cuisine}</p>
             <h3 className="text-3xl font-serif font-black text-white leading-none tracking-tighter drop-shadow-2xl">{restaurant.name}</h3>
           </div>
           <div className="bg-white/10 backdrop-blur-2xl border border-white/20 p-3 rounded-2xl text-white flex flex-col items-center shadow-2xl">
              <span className="google-symbols filled text-lemon text-xl">star</span>
              <span className="text-xs font-black mt-1">{restaurant.rating}</span>
           </div>
        </div>

        <div className="absolute top-6 right-6 flex flex-col gap-3">
          {userProfile && !aiVisionImage && (
            <button 
              onClick={(e) => { e.stopPropagation(); handleGenerateVision(); }}
              disabled={isGeneratingVision}
              className="w-12 h-12 bg-white/20 hover:bg-white/40 backdrop-blur-xl rounded-xl flex items-center justify-center text-white border border-white/30 shadow-2xl transition-all"
            >
              {isGeneratingVision ? <span className="google-symbols animate-spin text-xl">sync</span> : <span className="google-symbols text-xl">auto_awesome</span>}
            </button>
          )}
          {onViewOnMap && (
            <button 
              onClick={(e) => { e.stopPropagation(); onViewOnMap(); }}
              className="w-12 h-12 bg-sunset hover:bg-orange-600 rounded-xl flex items-center justify-center text-white transition-all shadow-2xl"
            >
              <span className="google-symbols">map</span>
            </button>
          )}
        </div>
      </div>

      <nav className="flex p-3 gap-2 bg-slate-50 dark:bg-slate-950/50">
         {(['info', 'reviews', 'wellness', 'order'] as const).map(tab => (
           <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 ${activeTab === tab ? 'bg-midnight dark:bg-white text-white dark:text-midnight shadow-lg' : 'text-slate-400'}`}>
              <span className="google-symbols text-sm">{tab === 'info' ? 'explore' : tab === 'reviews' ? 'forum' : tab === 'wellness' ? 'health_metrics' : 'shopping_bag'}</span> 
              <span>{tab}</span>
           </button>
         ))}
      </nav>

      <div className="p-8 min-h-[400px]">
        {activeTab === 'info' && (
          <div className="space-y-10 animate-in fade-in duration-500">
            <div className="space-y-4">
               <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Scout Analysis</h4>
               <div className="p-6 rounded-[2.5rem] bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-inner">
                  <p className="font-bold text-base leading-relaxed text-slate-700 dark:text-slate-200">{restaurant.whyMatch}</p>
               </div>
            </div>

            {restaurant.popularDishes && (
              <div className="space-y-4">
                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Signature Plates</h4>
                <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
                   {restaurant.popularDishes.map((dish, idx) => (
                     <div key={idx} className="flex-shrink-0 w-64 bg-white dark:bg-slate-800 p-5 rounded-[2.5rem] border-2 border-slate-50 dark:border-slate-800 space-y-3 shadow-md group">
                        <div className="flex justify-between items-start">
                           <div className="flex flex-col">
                              <span className="text-sm font-black text-slate-900 dark:text-white group-hover:text-sunset transition-colors">{dish.name}</span>
                              {dish.isVerified && <span className="text-[8px] font-black text-blue-500 uppercase flex items-center gap-1"><span className="google-symbols text-[10px] filled">verified</span> Verified</span>}
                           </div>
                           <span className="text-[10px] font-black text-sunset">{dish.price}</span>
                        </div>
                        <p className="text-[10px] text-slate-500 italic line-clamp-2 leading-relaxed">"{dish.description}"</p>
                        <a href={dish.orderUrl || restaurant.orderUrl} target="_blank" className="block w-full py-2.5 rounded-xl bg-sunset text-white text-[9px] font-black uppercase tracking-widest text-center no-underline hover:bg-orange-600 transition-all shadow-md">Order Now</a>
                     </div>
                   ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'order' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <header className="flex flex-col items-center text-center space-y-2 mb-4">
              <span className="text-4xl animate-bounce-slow">🚀</span>
              <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-400">Universal Ordering Hub</h4>
            </header>
            
            <div className="grid grid-cols-1 gap-5">
              {platforms.length > 0 ? platforms.map(p => (
                <a 
                  key={p.name}
                  href={p.url || '#'}
                  target="_blank"
                  className={`group relative overflow-hidden ${p.color} text-white p-7 rounded-[3rem] flex items-center justify-between shadow-2xl transition-all hover:scale-[1.02] border-b-[10px] border-black/10 no-underline`}
                >
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-white/20 rounded-[1.5rem] flex items-center justify-center backdrop-blur-md">
                      <span className="google-symbols text-3xl">{p.icon}</span>
                    </div>
                    <div className="text-left">
                      <span className="text-2xl font-serif font-black tracking-tight block leading-none">{p.name}</span>
                      <p className="text-[9px] font-black uppercase tracking-[0.2em] opacity-80 mt-1">{p.tagline}</p>
                    </div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center group-hover:translate-x-2 transition-transform">
                     <span className="google-symbols text-2xl">arrow_forward</span>
                  </div>
                </a>
              )) : (
                <div className="text-center py-24 opacity-30 grayscale space-y-6">
                   <span className="google-symbols text-6xl">link_off</span>
                   <p className="text-[10px] font-black uppercase tracking-[0.4em]">No ordering links grounded yet.</p>
                </div>
              )}
            </div>
            
            <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 text-center">
               <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] leading-relaxed">
                 Direct Partner Protocol: We prioritize deep menu links for the fastest checkout. 🍌
               </p>
            </div>
          </div>
        )}
        
        {activeTab === 'reviews' && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex justify-between items-center mb-4">
               <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400">Palate Feedback</h4>
               {!showReviewInput && (
                 <button 
                  onClick={() => setShowReviewInput(true)}
                  className="bg-sunset text-white px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest shadow-lg flex items-center gap-2"
                 >
                   <span className="google-symbols text-[14px]">edit</span> Post Review
                 </button>
               )}
            </div>

            {showReviewInput && (
              <div className="p-6 bg-slate-50 dark:bg-slate-800 rounded-[2.5rem] border-2 border-sunset/20 space-y-4 animate-in slide-in-from-top-4">
                 <textarea 
                   value={newReviewText}
                   onChange={(e) => setNewReviewText(e.target.value)}
                   placeholder="How was your sensory experience?"
                   className="w-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-700 rounded-2xl p-4 text-sm font-medium outline-none h-24"
                 />
                 <div className="flex justify-between items-center">
                    <div className="flex gap-1">
                       {[1,2,3,4,5].map(s => (
                         <button key={s} onClick={() => setNewReviewRating(s)} className={`google-symbols text-xl ${s <= newReviewRating ? 'text-amber-400 filled' : 'text-slate-300'}`}>star</button>
                       ))}
                    </div>
                    <div className="flex gap-2">
                       <button onClick={() => setShowReviewInput(false)} className="px-4 py-2 text-[10px] font-black uppercase tracking-widest text-slate-400">Cancel</button>
                       <button onClick={handlePostReview} className="px-6 py-2 bg-sunset text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">Post</button>
                    </div>
                 </div>
              </div>
            )}

            {restaurant.reviews.map((rev, i) => <ReviewItem key={i} review={rev} />)}
          </div>
        )}

        {activeTab === 'wellness' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="p-8 bg-emerald-50/50 dark:bg-emerald-950/20 border-2 border-emerald-100 dark:border-emerald-900/30 rounded-[3.5rem] space-y-6 shadow-sm">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900 rounded-2xl flex items-center justify-center text-emerald-600">
                    <span className="google-symbols text-3xl">health_metrics</span>
                  </div>
                  <h4 className="text-xl font-serif font-black text-emerald-800 dark:text-emerald-400">Nutritional Audit</h4>
               </div>
               <div className="grid grid-cols-2 gap-4">
                 {(restaurant.nutritionalHighlights || ['Balanced Macros', 'Ingredient Transparency', 'Whole Foods']).map((h, i) => (
                   <div key={i} className="bg-white dark:bg-slate-800 p-5 rounded-3xl flex items-center gap-3 shadow-md border border-emerald-50 dark:border-emerald-900/50">
                      <span className="google-symbols text-emerald-500 text-lg filled">verified</span>
                      <span className="text-[10px] font-black uppercase text-slate-700 dark:text-slate-200 tracking-tight leading-none">{h}</span>
                   </div>
                 ))}
               </div>
            </div>
          </div>
        )}
      </div>

      <footer className="px-10 pb-12 pt-6">
        <button 
          onClick={(e) => { e.stopPropagation(); onBook(); }}
          className="w-full bg-midnight dark:bg-white text-white dark:text-midnight py-8 rounded-[3rem] font-black uppercase tracking-[0.6em] text-[12px] shadow-3xl active:scale-95 transition-all flex items-center justify-center gap-4 border-b-[12px] border-black/30 group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-sunset translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out"></div>
          <span className="relative z-10 flex items-center gap-4">
            <span className="google-symbols text-2xl">event_available</span> 
            SECURE TABLE NODE 📅
          </span>
        </button>
      </footer>
    </article>
  );
};
