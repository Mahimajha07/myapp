
import React from 'react';

interface OrderTrackerProps {
  restaurantName: string;
  status: string;
  progress: number;
}

export const OrderTracker: React.FC<OrderTrackerProps> = ({ restaurantName, status, progress }) => {
  return (
    <div className="fixed bottom-24 left-6 right-6 z-[950] animate-in slide-in-from-bottom-10 duration-700">
      <div className="bg-midnight/95 backdrop-blur-3xl p-5 rounded-[2.5rem] shadow-2xl border border-white/10 flex items-center gap-4">
        <div className="w-12 h-12 bg-sunset rounded-2xl flex items-center justify-center text-white relative">
          <span className="google-symbols filled text-2xl">moped</span>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-mint rounded-full border-2 border-midnight"></div>
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-center mb-2">
            <h5 className="text-[11px] font-black text-white uppercase tracking-wider">{restaurantName}</h5>
            <span className="text-[8px] font-black text-mint uppercase tracking-[0.2em]">{status}</span>
          </div>
          <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-sunset to-lemon rounded-full transition-all duration-1000" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
        <button className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-white/50">
          <span className="google-symbols">keyboard_arrow_right</span>
        </button>
      </div>
    </div>
  );
};
