import React from 'react';

export const RestaurantCardSkeleton: React.FC = () => {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-[3.5rem] overflow-hidden border-2 border-slate-50 dark:border-slate-800 shadow-2xl animate-pulse">
      <div className="h-[32rem] bg-slate-100 dark:bg-slate-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
        <div className="absolute bottom-12 left-12 right-12 space-y-4">
          <div className="h-6 w-32 bg-slate-200 dark:bg-slate-700 rounded-full"></div>
          <div className="h-16 w-3/4 bg-slate-200 dark:bg-slate-700 rounded-2xl"></div>
          <div className="h-4 w-1/2 bg-slate-200 dark:bg-slate-700 rounded-full"></div>
        </div>
      </div>
      <div className="p-12 space-y-8">
        <div className="flex gap-4">
          <div className="h-14 flex-1 bg-slate-100 dark:bg-slate-800 rounded-2xl"></div>
          <div className="h-14 flex-1 bg-slate-100 dark:bg-slate-800 rounded-2xl"></div>
          <div className="h-14 flex-1 bg-slate-100 dark:bg-slate-800 rounded-2xl"></div>
        </div>
        <div className="h-40 bg-slate-50 dark:bg-slate-800/50 rounded-[2.5rem]"></div>
      </div>
      <style>{`
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};