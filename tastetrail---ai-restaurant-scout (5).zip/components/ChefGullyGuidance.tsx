
import React, { useState, useEffect } from 'react';

interface ChefGullyGuidanceProps {
  onComplete: () => void;
}

export const ChefGullyGuidance: React.FC<ChefGullyGuidanceProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  useEffect(() => {
    // Auto-advance or wait for clicks? Let's use clicks for better engagement
    if ('vibrate' in navigator) navigator.vibrate(10);
  }, [step]);

  return (
    <div className="fixed inset-0 z-[600] flex flex-col items-center justify-center p-8 overflow-hidden">
      {/* Dark backdrop with spotlight hole */}
      <div 
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm transition-all duration-700"
        style={{
          clipPath: step === 0 
            ? 'polygon(0% 0%, 0% 100%, 75% 100%, 75% 70%, 95% 70%, 95% 92%, 75% 92%, 75% 100%, 100% 100%, 100% 0%)'
            : 'none'
        }}
      />

      {/* Guidance Content */}
      <div className="relative z-10 max-w-xs text-center space-y-12 animate-in fade-in zoom-in duration-700">
        {step === 0 ? (
          <div className="space-y-8">
            <div className="relative">
               <div className="w-24 h-24 bg-white dark:bg-slate-900 rounded-[2rem] mx-auto flex items-center justify-center text-5xl shadow-2xl border-4 border-rose-500 animate-bounce">
                 🐒
               </div>
               <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-rose-600 rounded-full flex items-center justify-center text-white shadow-xl">
                 <span className="google-symbols animate-ping">touch_app</span>
               </div>
            </div>
            <div className="space-y-4">
              <h2 className="text-3xl font-serif font-black text-white leading-tight">Meet the Chef</h2>
              <p className="text-slate-300 font-medium text-lg leading-relaxed">
                Chef Gully is your <span className="text-rose-400 font-bold">Personal Gastro-Scout.</span> Tap him anytime for instant help!
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="relative">
               <div className="w-24 h-24 bg-rose-600 rounded-full mx-auto flex items-center justify-center text-white shadow-[0_0_50px_rgba(225,29,72,0.6)] border-4 border-white animate-pulse">
                 <span className="google-symbols text-5xl">mic</span>
               </div>
            </div>
            <div className="space-y-4">
              <h2 className="text-3xl font-serif font-black text-white leading-tight">Voice Powered</h2>
              <p className="text-slate-300 font-medium text-lg leading-relaxed">
                Don't like typing? Just <span className="text-emerald-400 font-bold">Speak your cravings</span> and let Gully hunt for you.
              </p>
            </div>
          </div>
        )}

        <button 
          onClick={() => step === 0 ? setStep(1) : onComplete()}
          className="w-full bg-white text-slate-950 py-6 rounded-[2rem] font-black uppercase tracking-[0.4em] text-sm shadow-2xl active:scale-95 transition-all"
        >
          {step === 0 ? "Next Tip" : "Let's Go!"}
        </button>
      </div>

      {/* Pointy indicator for Gully location */}
      {step === 0 && (
        <div className="fixed bottom-36 right-10 z-[610] animate-bounce text-rose-500">
          <span className="google-symbols text-7xl drop-shadow-[0_0_15px_rgba(225,29,72,0.8)]">arrow_downward</span>
        </div>
      )}
    </div>
  );
};
